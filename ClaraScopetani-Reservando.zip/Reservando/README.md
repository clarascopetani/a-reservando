# a-reservando
Reservando es un proyecto cuyo objetivo es poner en práctica los conceptos de refactoring, testing y TDD. Para esto, se utilizaran las bibliotecas Mocha y Chai. Luego de tener esas pruebas, mejorarás el código del proyecto o como se le dice en la industria, “refactorizarás” el código del mismo.

Además, vas a aplicar TDD (Test-driven development o desarrollo guiado por pruebas) una metodología de desarrollo de software muy utilizada en la industria.

REQUISITOS
Para realizar este proyecto es necesario manejarse con confianza con JavaScript: arreglos, bucles, condicionales y programación orientada a objetos.